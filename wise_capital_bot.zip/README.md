# Wise Capital Bot

Базовый шаблон Telegram/финансового бота на FastAPI.